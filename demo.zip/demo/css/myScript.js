function view_desktop(){
    var test_exist_mobile = $("#view-mode").hasClass("mobile");
    if(test_exist_mobile==true){
        $("#view-mode").removeClass("mobile");
        $("#view-mode").addClass("desktop");
        var window_width = window.innerWidth;
        if(window_width > 799){
            $("#view-mode > .frame > .controls > .ads").html("<img src='../home/image/banner_336x280.jpg'>");
        }else{
            $("#view-mode > .frame > .controls > .ads").html("<img src='../home/image/banner_728x90.jpg'>");
        }
    }
}
function view_mobile(){
    var test_exist_desktop = $("#view-mode").hasClass("desktop");
    if(test_exist_desktop==true){
        $("#view-mode").removeClass("desktop");
        $("#view-mode").addClass("mobile");
        $("#view-mode > .frame > .controls > .ads").html("<img src='../home/image/banner_728x90.jpg'>");
    }
}
function view_result() {
    var view_mode = $("#view-mode").hasClass("mobile");
    if(view_mode==true){//Mobile
        var text = editor.getValue();
        $("#view-mode > .frame > .controls > .ads").html("<img src='../home/image/banner_728x90.jpg'>");
        var ifr = document.createElement("iframe");
        ifr.setAttribute("id", "iframeResult");
        document.getElementById("iframe").innerHTML = "";
        document.getElementById("iframe").appendChild(ifr);
        var ifrw = (ifr.contentWindow) ? ifr.contentWindow : (ifr.contentDocument.document) ? ifr.contentDocument.document : ifr.contentDocument;
        ifrw.document.open();
        ifrw.document.write(text);
        ifrw.document.close();
    }else{//Desktop
        var window_width = window.innerWidth;
        if(window_width > 799){
            var text = editor.getValue();
            $("#view-mode > .frame > .controls > .ads").html("<img src='../home/image/banner_336x280.jpg'>");
            var ifr = document.createElement("iframe");
            ifr.setAttribute("id", "iframeResult");
            document.getElementById("iframe").innerHTML = "";
            document.getElementById("iframe").appendChild(ifr);
            var ifrw = (ifr.contentWindow) ? ifr.contentWindow : (ifr.contentDocument.document) ? ifr.contentDocument.document : ifr.contentDocument;
            ifrw.document.open();
            ifrw.document.write(text);
            ifrw.document.close();
        }else{
            var text = editor.getValue();
            $("#view-mode > .frame > .controls > .ads").html("<img src='../home/image/banner_728x90.jpg'>");
            var ifr = document.createElement("iframe");
            ifr.setAttribute("id", "iframeResult");
            document.getElementById("iframe").innerHTML = "";
            document.getElementById("iframe").appendChild(ifr);
            var ifrw = (ifr.contentWindow) ? ifr.contentWindow : (ifr.contentDocument.document) ? ifr.contentDocument.document : ifr.contentDocument;
            ifrw.document.open();
            ifrw.document.write(text);
            ifrw.document.close();
        }
    }
}
function view_result_default() {
    var text = editor.getValue();
    var ifr = document.createElement("iframe");
    ifr.setAttribute("id", "iframeResult");
    document.getElementById("iframe").innerHTML = "";
    document.getElementById("iframe").appendChild(ifr);
    var ifrw = (ifr.contentWindow) ? ifr.contentWindow : (ifr.contentDocument.document) ? ifr.contentDocument.document : ifr.contentDocument;
    ifrw.document.open();
    ifrw.document.write(text);
    ifrw.document.close();
}
function view_result_default_php() {
    var text = document.getElementById("textareaCode_php").value;
    var ifr = document.createElement("iframe");
    ifr.setAttribute("id", "iframeResult");
    document.getElementById("iframe").innerHTML = "";
    document.getElementById("iframe").appendChild(ifr);
    var ifrw = (ifr.contentWindow) ? ifr.contentWindow : (ifr.contentDocument.document) ? ifr.contentDocument.document : ifr.contentDocument;
    ifrw.document.open();
    ifrw.document.write(text);
    ifrw.document.close();
}
$(document).ready(function(){
    var window_width = window.innerWidth;
    if(window_width > 799){
        $("#window_width").html("than");
    }else{
        $("#window_width").html("less");
    }
    $(window).resize(function(){
        var view_mode_desktop = $("#view-mode").hasClass("desktop");
        if(view_mode_desktop==true){
            var window_width = window.innerWidth;
            var window_width_before = $("#window_width").html();
            if((window_width>799)&&(window_width_before=="less")){
                $("#view-mode > .frame > .controls > .ads").html("<img src='../home/image/banner_336x280.jpg'>");
                $("#window_width").html("than");
            }else if((window_width<=799)&&(window_width_before=="than")){
                $("#view-mode > .frame > .controls > .ads").html("<img src='../home/image/banner_728x90.jpg'>");
                $("#window_width").html("less");
            }
        }
    });
});